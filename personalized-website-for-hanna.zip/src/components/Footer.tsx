import { Heart, Sparkles } from "lucide-react";

export default function Footer() {
  return (
    <footer className="relative px-6 py-14 text-center">
      <div className="mx-auto flex max-w-xl flex-col items-center gap-4">
        <div className="flex items-center gap-3">
          <Heart size={18} fill="#FF9EBB" color="#FF9EBB" className="animate-heartbeat" style={{ animationDelay: "0s" }} />
          <Heart size={26} fill="#FF5C8A" color="#FF5C8A" className="animate-heartbeat" style={{ animationDelay: "0.25s" }} />
          <Heart size={18} fill="#FF9EBB" color="#FF9EBB" className="animate-heartbeat" style={{ animationDelay: "0.5s" }} />
        </div>
        <p className="font-hand text-4xl text-[#FF8FAB]">Handgemacht mit viel zu viel Liebe</p>
        <p className="inline-flex items-center gap-2 text-sm font-bold tracking-widest text-[#B08A96] uppercase">
          <Sparkles size={14} />
          Nur für Hanna – die Süßeste überhaupt
          <Sparkles size={14} />
        </p>
      </div>
    </footer>
  );
}
