import { useRef, useState } from "react";
import { motion, useInView } from "framer-motion";
import { Check, Heart, Sparkles } from "lucide-react";

const CHECKS = [
  "Zusammen sehen wir aus wie ein Werbespot für Sonnenschein.",
  "Du klaust mir Essen vom Teller – und ich lasse dich gewähren. DAS ist wahre Liebe.",
  "Zwei Blondinen, ein Team. Die Welt warnt uns, wir winken nur freundlich zurück.",
  "Mit dir ist sogar Warten irgendwie schön.",
];

export default function UsSection() {
  const meterRef = useRef<HTMLDivElement>(null);
  const inView = useInView(meterRef, { once: true, margin: "-120px" });
  const [full, setFull] = useState(false);

  return (
    <section className="bg-dots-faint relative overflow-hidden px-6 py-24">
      <div className="mx-auto grid max-w-6xl items-center gap-14 lg:grid-cols-2">
        {/* big polaroid */}
        <motion.div
          initial={{ opacity: 0, scale: 0.85, rotate: -8 }}
          whileInView={{ opacity: 1, scale: 1, rotate: -3 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ type: "spring", stiffness: 120, damping: 15 }}
          className="relative mx-auto w-full max-w-md"
        >
          <div className="relative rounded-3xl border border-[#F3E3DA] bg-white p-4 pb-16 shadow-[0_35px_70px_-30px_rgba(255,92,138,0.5)]">
            <img src="/images/couple.jpg" alt="Zwei blonde Verliebte als süße Illustration" className="aspect-square w-full rounded-2xl object-cover" />
            <p className="font-hand absolute bottom-4 left-0 w-full text-center text-3xl text-[#7A5560]">Blond & Blond – unschlagbar</p>
            <div
              className="pointer-events-none absolute -top-4 left-10 h-8 w-28 rotate-[-8deg] bg-[#FFD166]/80 shadow-sm"
              style={{ clipPath: "polygon(4% 0, 96% 6%, 100% 94%, 3% 100%)" }}
            />
            <div
              className="pointer-events-none absolute -top-4 right-10 h-8 w-28 rotate-[7deg] bg-[#FFB3C6]/80 shadow-sm"
              style={{ clipPath: "polygon(4% 0, 96% 6%, 100% 94%, 3% 100%)" }}
            />
          </div>

          <motion.div
            initial={{ opacity: 0, scale: 0, rotate: -20 }}
            whileInView={{ opacity: 1, scale: 1, rotate: 10 }}
            viewport={{ once: true }}
            transition={{ delay: 0.4, type: "spring", stiffness: 200, damping: 12 }}
            className="absolute -right-5 -bottom-8 w-32 md:-right-10"
          >
            <div className="animate-bob rounded-full border-4 border-white bg-white p-1.5 shadow-xl" style={{ animationDuration: "4s" }}>
              <img src="/images/cats.jpg" alt="Zwei kuschelnde Katzen" className="aspect-square w-full rounded-full object-cover" />
            </div>
            <p className="font-hand mt-1 text-center text-xl text-[#FF8FAB]">wir abends</p>
          </motion.div>
        </motion.div>

        {/* text side */}
        <div>
          <motion.p
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="font-hand text-4xl text-[#FF8FAB]"
          >
            offizielles Duo-Zertifikat
          </motion.p>
          <motion.h2
            initial={{ opacity: 0, y: 26 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1, type: "spring", stiffness: 140, damping: 16 }}
            className="font-bubble text-pop mt-2 text-5xl font-bold text-[#FF5C8A] md:text-6xl"
          >
            Blond trifft Blond
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="mt-5 max-w-lg text-lg leading-relaxed font-medium text-[#7A5560]"
          >
            Manche sagen, zwei Blondinen zusammen seien eine Gefahr für die Welt. Ich sage: Wir sind einfach das süßeste Team, das es je
            gegeben hat. Hiermit offiziell bestätigt:
          </motion.p>

          <ul className="mt-7 space-y-4">
            {CHECKS.map((c, i) => (
              <motion.li
                key={i}
                initial={{ opacity: 0, x: -30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.3 + i * 0.12 }}
                className="flex items-start gap-3 text-[17px] leading-snug font-semibold text-[#6E4A56]"
              >
                <span className="mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-[#FF5C8A] text-white shadow-md">
                  <Check size={16} strokeWidth={3.5} />
                </span>
                {c}
              </motion.li>
            ))}
          </ul>
        </div>

        {/* love meter */}
        <motion.div
          ref={meterRef}
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ type: "spring", stiffness: 120, damping: 16 }}
          className="relative rounded-[2.5rem] border-4 border-white bg-gradient-to-br from-[#FFDDE8] to-[#FFC9DA] p-8 shadow-[0_30px_60px_-25px_rgba(255,92,138,0.45)] md:p-10 lg:col-span-2"
        >
          <div className="flex flex-wrap items-center justify-between gap-3">
            <h3 className="font-bubble flex items-center gap-3 text-3xl font-bold text-[#C43B66]">
              <Heart size={28} fill="#FF5C8A" color="#FF5C8A" className="animate-heartbeat" />
              Der Hanna-Liebes-Messer
            </h3>
            <span className="rounded-full bg-white/70 px-4 py-1.5 text-sm font-bold tracking-wide text-[#C43B66] uppercase">hochpräzise Messung</span>
          </div>

          <div className="relative mt-7 h-12 overflow-hidden rounded-full border-4 border-white bg-white/60 shadow-inner">
            <motion.div
              initial={{ width: "0%" }}
              animate={inView ? { width: "100%" } : {}}
              transition={{ duration: 2.4, ease: "easeInOut", delay: 0.3 }}
              onAnimationComplete={() => setFull(true)}
              className="relative h-full rounded-full bg-gradient-to-r from-[#FF9EBB] via-[#FF5C8A] to-[#E83E75]"
            >
              <div className="absolute inset-0 rounded-full bg-[linear-gradient(120deg,transparent_20%,rgba(255,255,255,0.5)_50%,transparent_80%)] bg-[length:200%_100%]" />
            </motion.div>
          </div>

          <div className="mt-4 flex items-center justify-between">
            <p className="font-hand text-3xl text-[#C43B66]">
              {full ? "Messung abgebrochen: Skala gesprengt." : "Liebe wird gemessen …"}
            </p>
            {full ? (
              <motion.p
                initial={{ scale: 0, rotate: -20 }}
                animate={{ scale: 1, rotate: 0 }}
                transition={{ type: "spring", stiffness: 260, damping: 12 }}
                className="font-bubble flex items-center gap-2 text-3xl font-bold text-[#FF5C8A]"
              >
                ∞ unendlich
                <Sparkles size={24} className="animate-wiggle text-[#F5A623]" />
              </motion.p>
            ) : (
              <p className="font-bubble text-2xl font-bold text-[#E895B0]">lädt …</p>
            )}
          </div>

          {full && (
            <div className="pointer-events-none absolute inset-0">
              {Array.from({ length: 10 }).map((_, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 10, scale: 0 }}
                  animate={{ opacity: [0, 1, 0], y: -60, scale: [0, 1.3, 0.8] }}
                  transition={{ delay: i * 0.12, duration: 1.6, ease: "easeOut" }}
                  className="absolute"
                  style={{ left: `${6 + i * 10}%`, top: "30%" }}
                >
                  <Heart size={18 + (i % 3) * 6} fill={["#FF5C8A", "#FFD166", "#C9B6FF"][i % 3]} color="transparent" />
                </motion.div>
              ))}
            </div>
          )}
        </motion.div>
      </div>
    </section>
  );
}
