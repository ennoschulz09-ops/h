import { motion } from "framer-motion";
import { Coffee, Eye, Heart, Infinity as InfinityIcon, Star } from "lucide-react";

const MOMENTS = [
  {
    icon: Eye,
    color: "#FF5C8A",
    bg: "#FFE4EC",
    tag: "Kapitel 1",
    title: "Der erste Blick",
    text: "Mein Gehirn so: „Oh.“ Mein Herz so: „OH. OH. OH.“",
  },
  {
    icon: Coffee,
    color: "#F5A623",
    bg: "#FFF3D6",
    tag: "Kapitel 2",
    title: "Unser erstes richtiges Gespräch",
    text: "Stunden haben sich angefühlt wie Minuten. Experten nennen das übrigens ein sehr, sehr gutes Zeichen.",
  },
  {
    icon: Heart,
    color: "#9B7BE8",
    bg: "#EDE6FF",
    tag: "Kapitel 3",
    title: "Der Moment, als ich es wusste",
    text: "Aus „vielleicht“ wurde ganz leise „auf jeden Fall“. Und daran hat sich seitdem nichts geändert.",
  },
  {
    icon: Star,
    color: "#4CAF7D",
    bg: "#E3F4E8",
    tag: "Kapitel 4",
    title: "Heute",
    text: "Du bist mein Lieblingsmensch, mein Ruhepol und mein Abenteuer in einem. Alles gleichzeitig, jeden Tag.",
  },
  {
    icon: InfinityIcon,
    color: "#4C9BE8",
    bg: "#E0F1FF",
    tag: "Kapitel ∞",
    title: "Morgen",
    text: "Fortsetzung folgt. Und zwar für immer – wenn ich mir etwas aussuchen darf.",
  },
];

export default function Timeline() {
  return (
    <section className="relative overflow-hidden bg-[#FFF1F5] px-6 py-24">
      <div className="bg-dots absolute inset-0 opacity-40" />
      <div className="relative mx-auto max-w-4xl">
        <div className="mb-16 text-center">
          <motion.p
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="font-hand text-4xl text-[#FF8FAB]"
          >
            einmal blättern, bitte
          </motion.p>
          <motion.h2
            initial={{ opacity: 0, y: 26 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1, type: "spring", stiffness: 140, damping: 16 }}
            className="font-bubble text-pop mt-2 text-5xl font-bold text-[#FF5C8A] md:text-6xl"
          >
            Unser kleines Geschichtsbuch
          </motion.h2>
        </div>

        <div className="relative">
          <div className="absolute top-2 bottom-2 left-6 border-l-[3px] border-dashed border-[#FFB3C6] md:left-1/2 md:-translate-x-1/2" />

          {MOMENTS.map((m, i) => {
            const left = i % 2 === 0;
            return (
              <motion.div
                key={m.title}
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-60px" }}
                transition={{ type: "spring", stiffness: 130, damping: 16 }}
                className={`relative flex pb-12 pl-16 md:w-1/2 md:pl-0 ${left ? "md:justify-end md:pr-16" : "md:ml-auto md:pl-16"}`}
              >
                <span
                  className={`absolute top-5 left-6 z-10 flex h-12 w-12 -translate-x-1/2 items-center justify-center rounded-full border-4 border-white text-white shadow-lg md:translate-x-0 ${
                    left ? "md:-right-6 md:left-auto" : "md:-left-6"
                  }`}
                  style={{ backgroundColor: m.color }}
                >
                  <m.icon size={20} />
                </span>

                <motion.div
                  whileHover={{ scale: 1.03, rotate: left ? -1 : 1 }}
                  className="w-full max-w-md rounded-[1.8rem] border-4 border-white p-6 shadow-[0_20px_45px_-22px_rgba(255,92,138,0.4)]"
                  style={{ backgroundColor: m.bg }}
                >
                  <span
                    className="font-bubble inline-block rounded-full px-3 py-1 text-xs font-bold tracking-widest text-white uppercase"
                    style={{ backgroundColor: m.color }}
                  >
                    {m.tag}
                  </span>
                  <h3 className="font-bubble mt-3 text-2xl leading-tight font-semibold text-[#5A3A47]">{m.title}</h3>
                  <p className="mt-2 leading-relaxed font-medium text-[#7A5560]">{m.text}</p>
                </motion.div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
