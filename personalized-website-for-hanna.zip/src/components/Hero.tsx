import type { CSSProperties } from "react";
import { motion } from "framer-motion";
import { ArrowDown, Heart, MousePointerClick, Sparkles, Star } from "lucide-react";

const NAME = "Hanna!";

const FLOATERS = [
  { l: "8%", t: "24%", s: 20, c: "#FFB3C6", d: 3.6, r: "-10deg" },
  { l: "18%", t: "68%", s: 15, c: "#FFD166", d: 4.4, r: "8deg" },
  { l: "30%", t: "14%", s: 13, c: "#C9B6FF", d: 5.1, r: "6deg" },
  { l: "46%", t: "80%", s: 17, c: "#FF9EBB", d: 3.9, r: "-6deg" },
  { l: "63%", t: "12%", s: 16, c: "#FFC4D6", d: 4.7, r: "10deg" },
  { l: "75%", t: "74%", s: 21, c: "#FF5C8A", d: 3.4, r: "-12deg" },
  { l: "88%", t: "30%", s: 14, c: "#FFD166", d: 5.4, r: "4deg" },
  { l: "93%", t: "60%", s: 18, c: "#C9B6FF", d: 4.1, r: "-8deg" },
];

function Cloud({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 110 58" className={className} fill="#ffffff">
      <ellipse cx="30" cy="38" rx="24" ry="16" />
      <ellipse cx="58" cy="28" rx="27" ry="20" />
      <ellipse cx="82" cy="40" rx="22" ry="14" />
      <rect x="12" y="36" width="88" height="18" rx="9" />
    </svg>
  );
}

function Tape({ className }: { className?: string }) {
  return (
    <div
      className={`pointer-events-none absolute h-7 w-24 bg-[#FFD166]/80 shadow-sm ${className ?? ""}`}
      style={{ clipPath: "polygon(4% 0, 96% 6%, 100% 94%, 3% 100%)" }}
    />
  );
}

export default function Hero() {
  return (
    <section className="bg-dots relative flex min-h-[100svh] items-center justify-center overflow-hidden px-6 pt-20 pb-28">
      {/* drifting clouds */}
      <div className="animate-drift absolute top-[8%] left-0 opacity-80" style={{ animationDuration: "52s" }}>
        <Cloud className="w-36 drop-shadow-sm md:w-52" />
      </div>
      <div className="animate-drift absolute top-[22%] left-0 opacity-60" style={{ animationDuration: "75s", animationDelay: "-30s" }}>
        <Cloud className="w-24 md:w-36" />
      </div>
      <div className="animate-drift absolute top-[4%] left-0 opacity-70" style={{ animationDuration: "90s", animationDelay: "-60s" }}>
        <Cloud className="w-28 md:w-40" />
      </div>

      {/* floating hearts */}
      {FLOATERS.map((f, i) => (
        <div
          key={i}
          className="animate-bob absolute"
          style={{ left: f.l, top: f.t, animationDuration: `${f.d}s`, animationDelay: `${i * 0.35}s`, "--r": f.r } as CSSProperties}
        >
          <Heart size={f.s} fill={f.c} color={f.c} className="opacity-60" />
        </div>
      ))}

      {/* polaroid: couple */}
      <motion.div
        initial={{ opacity: 0, scale: 0.7, rotate: -14, y: 30 }}
        animate={{ opacity: 1, scale: 1, rotate: -6, y: 0 }}
        transition={{ delay: 1, type: "spring", stiffness: 130, damping: 14 }}
        className="absolute top-[15%] left-[4%] z-10 hidden w-52 lg:block xl:w-60"
      >
        <div className="animate-bob relative" style={{ animationDuration: "5s" }}>
          <div className="rounded-2xl border border-[#F3E3DA] bg-white p-3 pb-11 shadow-[0_24px_50px_-20px_rgba(255,92,138,0.45)]">
            <img src="/images/couple.jpg" alt="Wir zwei als süße Illustration" className="aspect-square w-full rounded-xl object-cover" />
            <p className="font-hand absolute bottom-2 left-0 w-full text-center text-2xl text-[#7A5560]">wir zwei</p>
          </div>
          <Tape className="-top-3 left-1/2 -translate-x-1/2 -rotate-6" />
        </div>
      </motion.div>

      {/* polaroid: bear */}
      <motion.div
        initial={{ opacity: 0, scale: 0.7, rotate: 14, y: 30 }}
        animate={{ opacity: 1, scale: 1, rotate: 5, y: 0 }}
        transition={{ delay: 1.2, type: "spring", stiffness: 130, damping: 14 }}
        className="absolute right-[4%] bottom-[14%] z-10 hidden w-44 lg:block xl:w-52"
      >
        <div className="animate-bob relative" style={{ animationDuration: "5.8s", animationDelay: "0.6s" }}>
          <div className="rounded-2xl border border-[#F3E3DA] bg-white p-3 pb-11 shadow-[0_24px_50px_-20px_rgba(255,92,138,0.4)]">
            <img src="/images/bear.jpg" alt="Süßer Bär mit Herz" className="aspect-square w-full rounded-xl object-cover" />
            <p className="font-hand absolute bottom-2 left-0 w-full text-center text-2xl text-[#7A5560]">dein Bodyguard</p>
          </div>
          <Tape className="-top-3 left-1/2 -translate-x-1/2 rotate-3" />
        </div>
      </motion.div>

      {/* center */}
      <div className="relative z-20 mx-auto max-w-3xl text-center">
        <motion.div
          initial={{ opacity: 0, y: 24, scale: 0.9 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          transition={{ delay: 0.15, type: "spring", stiffness: 160, damping: 16 }}
          className="mb-7 inline-flex items-center gap-2 rounded-full border-2 border-[#FFC4D6] bg-white/80 px-5 py-2.5 font-bold text-[#FF5C8A] shadow-lg backdrop-blur"
        >
          <Sparkles size={18} />
          Für die süßeste Person der Welt
          <Star size={16} fill="#FFD166" color="#FFD166" />
        </motion.div>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="font-hand text-5xl text-[#FF8FAB] md:text-6xl"
        >
          Hey,
        </motion.p>

        <h1 className="font-bubble bg-gradient-to-r from-[#FF5C8A] via-[#FF8FB0] to-[#FFB26B] bg-clip-text text-[clamp(4.5rem,17vw,11rem)] leading-[0.95] font-bold text-transparent">
          {NAME.split("").map((ch, i) => (
            <motion.span
              key={i}
              initial={{ y: 90, opacity: 0, rotate: -12 }}
              animate={{ y: 0, opacity: 1, rotate: 0 }}
              transition={{ delay: 0.45 + i * 0.09, type: "spring", stiffness: 320, damping: 16 }}
              whileHover={{ y: -18, rotate: 8, scale: 1.12 }}
              className="text-pop inline-block cursor-default"
            >
              {ch}
            </motion.span>
          ))}
        </h1>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.15 }}
          className="mx-auto mt-6 max-w-xl"
        >
          <p className="text-lg font-semibold text-[#8A6270] md:text-xl">
            Ich hab dir etwas gebaut – mit viel Liebe, ganz viel Rosa
            <br className="hidden md:block" /> und einer Prise Glitzer.{" "}
            <span className="font-hand text-3xl whitespace-nowrap text-[#FF5C8A]">Nur für dich.</span>
          </p>
          <svg viewBox="0 0 220 14" className="mx-auto mt-1 w-52" fill="none">
            <path d="M4 9c18-8 26-8 44 0s26 8 44 0 26-8 44 0 26 8 44 0 26-8 36 0" stroke="#FF9EBB" strokeWidth="5" strokeLinecap="round" />
          </svg>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.35 }}
          className="mt-10 flex flex-wrap items-center justify-center gap-4"
        >
          <a
            href="#gruende"
            className="group font-bubble inline-flex items-center gap-2 rounded-full bg-[#FF5C8A] px-8 py-4 text-xl text-white shadow-[0_14px_30px_-8px_rgba(255,92,138,0.55)] transition-transform duration-200 hover:scale-105 hover:-rotate-1 active:scale-95"
          >
            Zeig her!
            <ArrowDown size={20} className="transition-transform group-hover:translate-y-1" />
          </a>
          <a
            href="#briefe"
            className="font-bubble inline-flex items-center gap-2 rounded-full border-[3px] border-dashed border-[#FFB3C6] bg-white px-8 py-4 text-xl text-[#FF5C8A] shadow-md transition-transform duration-200 hover:scale-105 hover:rotate-1 active:scale-95"
          >
            <Heart size={20} fill="#FF5C8A" />
            Erst mal ein Bussi
          </a>
        </motion.div>
      </div>

      {/* scroll cue */}
      <motion.a
        href="#gruende"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 2 }}
        className="absolute bottom-6 left-1/2 z-20 -translate-x-1/2 text-center"
      >
        <motion.div animate={{ y: [0, 9, 0] }} transition={{ repeat: Infinity, duration: 1.6, ease: "easeInOut" }}>
          <p className="font-hand text-2xl text-[#FF8FAB]">scroll mal, Schatz</p>
          <MousePointerClick size={26} className="mx-auto mt-1 text-[#FF5C8A]" />
        </motion.div>
      </motion.a>
    </section>
  );
}
