import { useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Heart, MousePointerClick } from "lucide-react";

type BurstHeart = {
  id: number;
  tx: number;
  ty: number;
  rot: number;
  size: number;
  color: string;
};

const COLORS = ["#FF5C8A", "#FF9EBB", "#FFD166", "#C9B6FF", "#FFFFFF", "#FF8FAB"];

const MSGS = [
  "Beweis erbracht: Es sprudelt.",
  "Immer noch der Fall. Sogar mehr.",
  "Übrigens gilt das: für immer.",
  "Du kannst aufhören zu drücken … aber bitte hör nicht auf.",
  "Ja, ja und noch tausendmal ja.",
];

export default function Finale() {
  const [presses, setPresses] = useState(0);
  const [hearts, setHearts] = useState<BurstHeart[]>([]);
  const idRef = useRef(0);

  const explode = () => {
    const batch: BurstHeart[] = Array.from({ length: 26 }).map(() => {
      idRef.current += 1;
      const angle = Math.random() * Math.PI * 2;
      const dist = 90 + Math.random() * 190;
      return {
        id: idRef.current,
        tx: Math.cos(angle) * dist,
        ty: Math.sin(angle) * dist - 60,
        rot: Math.random() * 80 - 40,
        size: 14 + Math.random() * 22,
        color: COLORS[Math.floor(Math.random() * COLORS.length)],
      };
    });
    setHearts((h) => [...h.slice(-120), ...batch]);
    window.setTimeout(() => {
      setHearts((h) => h.filter((x) => !batch.some((b) => b.id === x.id)));
    }, 1500);
    setPresses((p) => p + 1);
  };

  return (
    <section className="relative overflow-hidden bg-gradient-to-b from-[#FFE4EC] via-[#FFD1DE] to-[#FF9EBB] px-6 pt-28 pb-32">
      {/* soft glow */}
      <div className="pointer-events-none absolute top-1/2 left-1/2 h-[560px] w-[560px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-white/40 blur-3xl" />

      <div className="relative mx-auto max-w-3xl text-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.6, rotate: -10 }}
          whileInView={{ opacity: 1, scale: 1, rotate: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ type: "spring", stiffness: 160, damping: 13 }}
          className="relative mx-auto mb-8 w-40 md:w-48"
        >
          <div className="animate-bob rounded-full border-[6px] border-white bg-white p-2 shadow-2xl" style={{ animationDuration: "4.2s" }}>
            <img src="/images/cats.jpg" alt="Zwei kuschelnde Katzen" className="aspect-square w-full rounded-full object-cover" />
          </div>
          <div className="animate-heartbeat absolute -top-2 -right-2 rounded-full bg-white p-2.5 shadow-lg">
            <Heart size={26} fill="#FF5C8A" color="#FF5C8A" />
          </div>
        </motion.div>

        <motion.p
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="font-hand text-4xl text-[#C43B66] md:text-5xl"
        >
          und zum Schluss das Allerwichtigste:
        </motion.p>

        <motion.h2
          initial={{ opacity: 0, y: 30, scale: 0.94 }}
          whileInView={{ opacity: 1, y: 0, scale: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.12, type: "spring", stiffness: 130, damping: 15 }}
          className="font-bubble text-pop mt-4 text-[clamp(2.6rem,8vw,5.5rem)] leading-[1.02] font-bold text-white"
        >
          Hanna,
          <br />
          ich hab dich
          <br />
          <span className="text-[#FFD166]">sooo</span> lieb!
        </motion.h2>

        <motion.p
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.3 }}
          className="mx-auto mt-6 max-w-md text-lg font-semibold text-[#A34361]"
        >
          Falls du noch einen offiziellen Beleg brauchst – hier, bitte sehr:
        </motion.p>

        {/* explosion button */}
        <div className="relative mx-auto mt-10 inline-block">
          <AnimatePresence>
            {hearts.map((h) => (
              <motion.span
                key={h.id}
                initial={{ x: 0, y: 0, scale: 0, opacity: 1, rotate: 0 }}
                animate={{ x: h.tx, y: h.ty, scale: [0, 1.25, 1], opacity: [1, 1, 0], rotate: h.rot }}
                exit={{ opacity: 0 }}
                transition={{ duration: 1.35, ease: "easeOut" }}
                className="pointer-events-none absolute top-1/2 left-1/2 z-30"
              >
                <Heart size={h.size} fill={h.color} color={h.color} strokeWidth={1} stroke="#fff" />
              </motion.span>
            ))}
          </AnimatePresence>

          <motion.button
            onClick={explode}
            whileHover={{ scale: 1.07, rotate: -2 }}
            whileTap={{ scale: 0.9, rotate: 2 }}
            className="font-bubble relative z-10 inline-flex cursor-pointer items-center gap-3 rounded-full border-4 border-white bg-[#FF5C8A] px-10 py-5 text-2xl font-bold text-white shadow-[0_20px_45px_-12px_rgba(200,40,90,0.6)]"
          >
            <MousePointerClick size={26} />
            {presses === 0 ? "Drücken für Beweis" : "Noch mehr Beweise!"}
          </motion.button>
        </div>

        <div className="mt-7 min-h-16">
          {presses > 0 && (
            <motion.div key={presses} initial={{ opacity: 0, y: 14, scale: 0.95 }} animate={{ opacity: 1, y: 0, scale: 1 }}>
              <p className="font-hand text-4xl text-[#C43B66]">{MSGS[Math.min(presses - 1, MSGS.length - 1)]}</p>
              <p className="mt-1 text-sm font-bold tracking-wide uppercase" style={{ color: "#B85571" }}>
                Bereits {presses * 26}+ Herzen freigelassen
              </p>
            </motion.div>
          )}
        </div>
      </div>
    </section>
  );
}
