import { motion } from "framer-motion";
import { Gauge, HeartPulse, Laugh, Zap } from "lucide-react";

const FACTS = [
  { icon: Gauge, value: "über 9000", label: "offizielles Süße-Level", bg: "#FFE4EC", iconBg: "#FF5C8A", rot: "-1.5deg" },
  { icon: Zap, value: "200 %", label: "Blondinen-Power im Haus", bg: "#FFF3D6", iconBg: "#F5A623", rot: "1.5deg" },
  { icon: HeartPulse, value: "∞", label: "benötigte Umarmungen pro Tag", bg: "#EDE6FF", iconBg: "#9B7BE8", rot: "-1deg" },
  { icon: Laugh, value: "unzählbar", label: "gemeinsame Lacher (und Zählen)", bg: "#E3F4E8", iconBg: "#4CAF7D", rot: "2deg" },
];

export default function Facts() {
  return (
    <section className="bg-dots-faint relative px-6 py-20">
      <div className="mx-auto grid max-w-6xl grid-cols-2 gap-5 md:gap-8 lg:grid-cols-4">
        {FACTS.map((f, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, y: 40, rotate: 0 }}
            whileInView={{ opacity: 1, y: 0, rotate: Number.parseFloat(f.rot) }}
            viewport={{ once: true, margin: "-60px" }}
            transition={{ delay: i * 0.12, type: "spring", stiffness: 140, damping: 15 }}
            whileHover={{ scale: 1.06, rotate: 0, y: -8 }}
            className="rounded-[2rem] border-4 border-white p-6 text-center shadow-[0_20px_45px_-20px_rgba(255,92,138,0.35)]"
            style={{ backgroundColor: f.bg }}
          >
            <div
              className="animate-wiggle mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-full text-white shadow-md"
              style={{ backgroundColor: f.iconBg, animationDelay: `${i * 0.25}s` }}
            >
              <f.icon size={26} />
            </div>
            <p className="font-bubble text-3xl font-bold text-[#5A3A47] md:text-4xl">{f.value}</p>
            <p className="mt-1 text-sm leading-snug font-semibold text-[#8A6270]">{f.label}</p>
          </motion.div>
        ))}
      </div>
      <p className="font-hand mt-8 text-center text-3xl text-[#FF8FAB]">* wissenschaftlich geprüft. Von mir. Sehr seriös.</p>
    </section>
  );
}
