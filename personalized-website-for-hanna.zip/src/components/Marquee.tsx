import { Flower2, Heart, Sparkles, Star } from "lucide-react";

const WORDS = ["SUPER SÜSS", "SONNENSCHEIN", "HERZENSGUT", "BLOND & WUNDERSCHÖN", "TRAUMFRAU", "KUSCHELKÖNIGIN", "EINZIGARTIG", "ZAUBERHAFT"];
const ICONS = [Heart, Star, Sparkles, Flower2];

function Row() {
  return (
    <div className="flex shrink-0 items-center">
      {WORDS.map((w, i) => {
        const Icon = ICONS[i % ICONS.length];
        return (
          <span key={i} className="flex items-center">
            <span className="font-bubble px-7 text-xl tracking-wider whitespace-nowrap md:text-2xl">{w}</span>
            <Icon size={20} fill="currentColor" className="shrink-0 opacity-90" />
          </span>
        );
      })}
    </div>
  );
}

export default function Marquee() {
  return (
    <div className="relative z-30 my-2 overflow-visible py-8">
      <div className="relative z-10 -mx-[2%] w-[104%] -rotate-[1.6deg] overflow-hidden bg-[#FF5C8A] py-4 text-white shadow-[0_18px_40px_-18px_rgba(255,92,138,0.7)]">
        <div className="animate-marquee flex w-max">
          <Row />
          <Row />
        </div>
      </div>
      <div className="relative -mx-[2%] -mt-7 w-[104%] rotate-[1.3deg] overflow-hidden bg-[#FFD166] py-4 text-[#8A6A00] shadow-md">
        <div className="animate-marquee flex w-max" style={{ animationDirection: "reverse", animationDuration: "30s" }}>
          <Row />
          <Row />
        </div>
      </div>
    </div>
  );
}
