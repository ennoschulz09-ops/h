import { useEffect, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Heart } from "lucide-react";

type Puff = {
  id: number;
  x: number;
  y: number;
  size: number;
  color: string;
  rot: number;
  drift: number;
};

const COLORS = ["#FF5C8A", "#FF9EBB", "#FFD166", "#C9B6FF", "#8AD6FF", "#FF8FAB"];

export default function CursorHearts() {
  const [puffs, setPuffs] = useState<Puff[]>([]);
  const idRef = useRef(0);
  const lastRef = useRef({ x: 0, y: 0, t: 0 });

  useEffect(() => {
    const spawn = (x: number, y: number, n: number, big: boolean) => {
      const items: Puff[] = [];
      for (let i = 0; i < n; i++) {
        idRef.current += 1;
        items.push({
          id: idRef.current,
          x: x + (Math.random() * 30 - 15),
          y: y + (Math.random() * 20 - 10),
          size: big ? 12 + Math.random() * 22 : 9 + Math.random() * 10,
          color: COLORS[Math.floor(Math.random() * COLORS.length)],
          rot: Math.random() * 50 - 25,
          drift: Math.random() * 40 - 20,
        });
      }
      setPuffs((p) => [...p.slice(-45), ...items]);
      window.setTimeout(() => {
        setPuffs((p) => p.filter((pp) => !items.some((it) => it.id === pp.id)));
      }, 1200);
    };

    const onMove = (e: MouseEvent) => {
      const now = performance.now();
      const dx = e.clientX - lastRef.current.x;
      const dy = e.clientY - lastRef.current.y;
      if (Math.hypot(dx, dy) > 90 && now - lastRef.current.t > 70) {
        lastRef.current = { x: e.clientX, y: e.clientY, t: now };
        spawn(e.clientX, e.clientY, 1, false);
      }
    };
    const onClick = (e: MouseEvent) => spawn(e.clientX, e.clientY, 8, true);
    const onTouch = (e: TouchEvent) => {
      const t = e.touches[0];
      if (t) spawn(t.clientX, t.clientY, 5, true);
    };

    window.addEventListener("mousemove", onMove);
    window.addEventListener("click", onClick);
    window.addEventListener("touchstart", onTouch);
    return () => {
      window.removeEventListener("mousemove", onMove);
      window.removeEventListener("click", onClick);
      window.removeEventListener("touchstart", onTouch);
    };
  }, []);

  return (
    <div className="pointer-events-none fixed inset-0 z-[100] overflow-hidden">
      <AnimatePresence>
        {puffs.map((p) => (
          <motion.div
            key={p.id}
            initial={{ opacity: 0.95, scale: 0, x: p.x, y: p.y, rotate: p.rot }}
            animate={{ opacity: 0, scale: 1.25, x: p.x + p.drift, y: p.y - 90 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 1.05, ease: "easeOut" }}
            className="absolute left-0 top-0"
          >
            <Heart size={p.size} fill={p.color} color={p.color} strokeWidth={1.5} />
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
}
