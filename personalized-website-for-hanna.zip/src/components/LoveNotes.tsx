import { useState } from "react";
import { motion } from "framer-motion";
import { Heart, MailOpen } from "lucide-react";

const NOTES = [
  {
    label: "Für schlechte Tage",
    color: "#FF9EBB",
    flap: "#FF7FA8",
    flapOpen: "#FF8FB6",
    rot: "-1.5deg",
    text: "Wenn der Tag doof ist: Denk dran – du bist mein Lieblingsmensch. Und Lieblingsmenschen haben immer mindestens einen riesigen Fan. Nämlich mich.",
  },
  {
    label: "Wenn du an mich denkst",
    color: "#FFB26B",
    flap: "#F59C50",
    flapOpen: "#FFA763",
    rot: "1.2deg",
    text: "… dann kannst du dir ziemlich sicher sein, dass ich in genau diesem Moment auch an dich denke. Oder an Snacks. Aber meistens an dich.",
  },
  {
    label: "Streng geheim",
    color: "#C9B6FF",
    flap: "#AE97F2",
    flapOpen: "#BBA6F5",
    rot: "-1deg",
    text: "Ich lächle immer noch wie ein Honigkuchenpferd, wenn dein Name auf meinem Handy aufleuchtet. Jedes. Einzelne. Mal.",
  },
];

function Envelope({ note, index }: { note: (typeof NOTES)[number]; index: number }) {
  const [open, setOpen] = useState(false);

  return (
    <motion.div
      initial={{ opacity: 0, y: 50 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-60px" }}
      transition={{ delay: index * 0.15, type: "spring", stiffness: 130, damping: 16 }}
      className="flex flex-col items-center"
      style={{ rotate: note.rot }}
    >
      <p className="font-hand mb-3 text-3xl text-[#8A6270]">
        Brief Nr. {index + 1} – {note.label}
      </p>

      <button
        onClick={() => setOpen((o) => !o)}
        className="relative block h-80 w-full max-w-sm cursor-pointer select-none"
        style={{ perspective: 900 }}
        aria-label={`${note.label} – zum Öffnen tippen`}
      >
        {/* the letter */}
        <motion.div
          animate={open ? { y: -125, rotate: 1.5, scale: 1.02 } : { y: 0, rotate: -1 }}
          transition={{ type: "spring", stiffness: 110, damping: 15 }}
          className="absolute inset-x-5 top-6 z-10 rounded-xl border-2 border-dashed border-[#FFD9E4] bg-[#FFFBF4] p-5 text-left shadow-lg"
        >
          <p className="font-hand text-2xl leading-snug text-[#7A5560]">{note.text}</p>
          <Heart size={16} fill="#FF5C8A" color="#FF5C8A" className="mt-2 ml-auto" />
        </motion.div>

        {/* envelope pocket */}
        <div
          className="absolute inset-x-0 top-24 right-0 bottom-0 z-20 overflow-hidden rounded-b-2xl rounded-t-md shadow-[0_25px_50px_-20px_rgba(110,74,86,0.45)]"
          style={{ backgroundColor: note.color }}
        >
          <svg className="absolute inset-0 h-full w-full opacity-25" preserveAspectRatio="none" viewBox="0 0 100 100">
            <path d="M0 0 L50 55 L100 0" stroke="#fff" strokeWidth="2.5" fill="none" />
            <path d="M0 100 L38 45 M100 100 L62 45" stroke="#fff" strokeWidth="2.5" fill="none" />
          </svg>
          <motion.div
            animate={{ opacity: open ? 0 : 1, scale: open ? 0.4 : 1 }}
            className="absolute top-[34%] left-1/2 flex h-14 w-14 -translate-x-1/2 items-center justify-center rounded-full bg-white shadow-md"
          >
            <Heart size={26} fill="#FF5C8A" color="#FF5C8A" />
          </motion.div>
        </div>

        {/* flap */}
        <motion.div
          animate={{ rotateX: open ? -168 : 0 }}
          transition={{ type: "spring", stiffness: 160, damping: 18 }}
          className="absolute inset-x-0 top-24 z-30 h-[42%] origin-top shadow-sm"
          style={{
            clipPath: "polygon(0 0, 100% 0, 50% 100%)",
            backgroundColor: open ? note.flapOpen : note.flap,
            backfaceVisibility: "hidden",
          }}
        />
      </button>

      <motion.p
        animate={{ opacity: open ? 0 : 1 }}
        className="mt-4 inline-flex items-center gap-2 text-sm font-bold tracking-wide text-[#B08A96] uppercase"
      >
        <MailOpen size={16} /> tippen zum Öffnen
      </motion.p>
    </motion.div>
  );
}

export default function LoveNotes() {
  return (
    <section id="briefe" className="relative overflow-hidden bg-[#FFE9F0] px-6 py-24">
      <div className="bg-dots absolute inset-0 opacity-40" />
      <div className="relative mx-auto max-w-6xl">
        <div className="mb-16 text-center">
          <motion.p
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="font-hand text-4xl text-[#FF8FAB]"
          >
            Post ist da!
          </motion.p>
          <motion.h2
            initial={{ opacity: 0, y: 26 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1, type: "spring", stiffness: 140, damping: 16 }}
            className="font-bubble text-pop mt-2 text-5xl font-bold text-[#FF5C8A] md:text-6xl"
          >
            Kleine Briefe für dich
          </motion.h2>
          <p className="mt-3 text-lg font-semibold text-[#8A6270]">Handschriftlich gedacht, digital verpackt</p>
        </div>

        <div className="grid gap-14 md:grid-cols-3 md:gap-8">
          {NOTES.map((n, i) => (
            <Envelope key={n.label} note={n} index={i} />
          ))}
        </div>
      </div>
    </section>
  );
}
