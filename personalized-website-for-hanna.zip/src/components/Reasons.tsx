import { motion } from "framer-motion";
import { Crown, HeartHandshake, Laugh, Smile, Sparkles, Star } from "lucide-react";

const REASONS = [
  {
    icon: Smile,
    title: "Dein Lächeln",
    text: "Damit zauberst du mir selbst am Montagmorgen um 6 Uhr ein Grinsen ins Gesicht.",
    bg: "#FFE4EC",
    iconBg: "#FF5C8A",
    rot: "-2deg",
  },
  {
    icon: Laugh,
    title: "Dein Lachen",
    text: "Mein absoluter Lieblingssong. Könnte ich mir in Dauerschleife anhören.",
    bg: "#FFF3D6",
    iconBg: "#F5A623",
    rot: "1.8deg",
  },
  {
    icon: Sparkles,
    title: "Deine blonden Haare",
    text: "Blond wie Sonnenschein. Zum Glück bin ich auch blond – sonst würdest du mich komplett überstrahlen.",
    bg: "#EDE6FF",
    iconBg: "#9B7BE8",
    rot: "-1.5deg",
  },
  {
    icon: HeartHandshake,
    title: "Deine Umarmungen",
    text: "Der gemütlichste Ort der Welt. Wissenschaftlich belegt. Meine Wissenschaft.",
    bg: "#E3F4E8",
    iconBg: "#4CAF7D",
    rot: "2deg",
  },
  {
    icon: Crown,
    title: "Deine Art",
    text: "Du machst alles um dich herum ein bisschen schöner – ohne es überhaupt zu merken.",
    bg: "#FFE9DD",
    iconBg: "#F08A4B",
    rot: "-2.2deg",
  },
  {
    icon: Star,
    title: "Einfach DU",
    text: "Weil du du bist. Mehr muss man dazu eigentlich gar nicht sagen.",
    bg: "#E0F1FF",
    iconBg: "#4C9BE8",
    rot: "1.5deg",
  },
];

export default function Reasons() {
  return (
    <section id="gruende" className="relative px-6 py-24">
      <div className="mx-auto mb-14 max-w-3xl text-center">
        <motion.p
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="font-hand text-4xl text-[#FF8FAB]"
        >
          Achtung, jetzt wird's emotional …
        </motion.p>
        <motion.h2
          initial={{ opacity: 0, y: 26 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.1, type: "spring", stiffness: 140, damping: 16 }}
          className="font-bubble text-pop mt-2 text-5xl font-bold text-[#FF5C8A] md:text-6xl"
        >
          Ein paar von mindestens 1000 Gründen
        </motion.h2>
        <motion.p
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.25 }}
          className="mt-3 text-lg font-semibold text-[#8A6270]"
        >
          warum ich dich so unglaublich gern hab
        </motion.p>
      </div>

      <div className="mx-auto grid max-w-6xl gap-7 sm:grid-cols-2 lg:grid-cols-3">
        {REASONS.map((r, i) => (
          <motion.div
            key={r.title}
            initial={{ opacity: 0, y: 50, rotate: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, y: 0, rotate: Number.parseFloat(r.rot), scale: 1 }}
            viewport={{ once: true, margin: "-40px" }}
            transition={{ delay: (i % 3) * 0.12, type: "spring", stiffness: 130, damping: 15 }}
            whileHover={{ scale: 1.05, rotate: 0, y: -10 }}
            className="group relative cursor-default rounded-[2rem] border-4 border-white p-7 shadow-[0_24px_50px_-22px_rgba(255,92,138,0.4)]"
            style={{ backgroundColor: r.bg }}
          >
            <div className="mb-5 flex items-center gap-4">
              <div
                className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl text-white shadow-md transition-transform duration-300 group-hover:rotate-12 group-hover:scale-110"
                style={{ backgroundColor: r.iconBg }}
              >
                <r.icon size={27} />
              </div>
              <h3 className="font-bubble text-2xl leading-tight font-semibold text-[#5A3A47]">{r.title}</h3>
            </div>
            <p className="leading-relaxed font-medium text-[#7A5560]">{r.text}</p>
          </motion.div>
        ))}
      </div>
    </section>
  );
}
