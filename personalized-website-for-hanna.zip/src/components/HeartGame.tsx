import { useEffect, useRef, useState, type PointerEvent } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { MousePointerClick, Sparkles, Target } from "lucide-react";

type FlyHeart = { id: number; left: number; size: number; dur: number; color: string };
type Burst = { id: number; x: number; y: number; color: string; angle: number };

const COLORS = ["#FF5C8A", "#FF9EBB", "#FFB3C6", "#FFD166", "#C9B6FF", "#FF8FAB"];

function HeartShape({ size, color }: { size: number; color: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill={color} className="drop-shadow-md">
      <path d="M12 21s-8-5.5-8-11a4.5 4.5 0 0 1 8-3 4.5 4.5 0 0 1 8 3c0 5.5-8 11-8 11z" />
    </svg>
  );
}

function message(score: number) {
  if (score >= 50) return "Okay. Du besitzt jetzt offiziell ALLE meine Herzen. Keine Sorge – es wachsen laufend neue nach.";
  if (score >= 25) return "Herzprofi-Status erreicht. Ich bin beeindruckt. Und verliebt.";
  if (score >= 12) return "Wow! Mein Herz macht gerade Purzelbäume für dich.";
  if (score >= 5) return "Gut gefangen, Schatz!";
  return "Fang so viele du kannst – sie schweben nur für dich hier hoch.";
}

export default function HeartGame() {
  const [hearts, setHearts] = useState<FlyHeart[]>([]);
  const [bursts, setBursts] = useState<Burst[]>([]);
  const [score, setScore] = useState(0);
  const idRef = useRef(0);
  const boxRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const t = window.setInterval(() => {
      setHearts((h) => {
        if (h.length >= 9) return h;
        idRef.current += 1;
        return [
          ...h,
          {
            id: idRef.current,
            left: 4 + Math.random() * 88,
            size: 30 + Math.random() * 26,
            dur: 6 + Math.random() * 4,
            color: COLORS[Math.floor(Math.random() * COLORS.length)],
          },
        ];
      });
    }, 850);
    return () => window.clearInterval(t);
  }, []);

  const pop = (e: PointerEvent, heart: FlyHeart) => {
    e.stopPropagation();
    const rect = boxRef.current?.getBoundingClientRect();
    const x = rect ? e.clientX - rect.left : 0;
    const y = rect ? e.clientY - rect.top : 0;
    setHearts((h) => h.filter((hh) => hh.id !== heart.id));
    setScore((s) => s + 1);
    const parts: Burst[] = Array.from({ length: 7 }).map((_, i) => {
      idRef.current += 1;
      return { id: idRef.current, x, y, color: COLORS[i % COLORS.length], angle: (i / 7) * Math.PI * 2 + Math.random() * 0.5 };
    });
    setBursts((b) => [...b, ...parts]);
    window.setTimeout(() => {
      setBursts((b) => b.filter((bb) => !parts.some((p) => p.id === bb.id)));
    }, 700);
  };

  return (
    <section className="relative px-6 py-24">
      <div className="mx-auto max-w-5xl">
        <div className="mb-10 text-center">
          <motion.p
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="font-hand text-4xl text-[#FF8FAB]"
          >
            Zeit für ein Spielchen
          </motion.p>
          <motion.h2
            initial={{ opacity: 0, y: 26 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1, type: "spring", stiffness: 140, damping: 16 }}
            className="font-bubble text-pop mt-2 text-5xl font-bold text-[#FF5C8A] md:text-6xl"
          >
            Fang meine Herzen!
          </motion.h2>
        </div>

        <div className="mb-6 flex flex-wrap items-center justify-between gap-4 px-2">
          <div className="flex items-center gap-3 rounded-full border-2 border-[#FFC4D6] bg-white px-5 py-2 shadow-md">
            <HeartShape size={22} color="#FF5C8A" />
            <span className="font-bubble text-2xl font-bold text-[#5A3A47]">{score}</span>
            <span className="font-semibold text-[#8A6270]">gefangen</span>
          </div>
          <p className="font-hand max-w-md text-2xl text-[#8A6270] md:text-right">{message(score)}</p>
        </div>

        <motion.div
          ref={boxRef}
          initial={{ opacity: 0, scale: 0.96 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ type: "spring", stiffness: 140, damping: 18 }}
          className="bg-dots relative h-[440px] overflow-hidden rounded-[2.5rem] border-4 border-dashed border-[#FFB3C6] bg-gradient-to-b from-[#FFF3F7] to-[#FFE4EC] shadow-inner"
        >
          <div className="pointer-events-none absolute inset-x-0 top-0 flex justify-center pt-5 opacity-70">
            <span className="inline-flex items-center gap-2 rounded-full bg-white/80 px-4 py-1.5 text-sm font-bold text-[#C98AA0]">
              <MousePointerClick size={15} /> tippen & klicken zum Fangen
            </span>
          </div>

          <AnimatePresence>
            {hearts.map((h) => (
              <motion.button
                key={h.id}
                initial={{ y: 460, x: 0, rotate: -8 }}
                animate={{ y: -100, rotate: 8 }}
                transition={{ duration: h.dur, ease: "linear" }}
                onAnimationComplete={() => setHearts((hh) => hh.filter((x) => x.id !== h.id))}
                onPointerDown={(e) => pop(e, h)}
                whileHover={{ scale: 1.25 }}
                className="absolute bottom-0 cursor-pointer p-1"
                style={{ left: `${h.left}%` }}
                aria-label="Herz fangen"
              >
                <HeartShape size={h.size} color={h.color} />
              </motion.button>
            ))}
          </AnimatePresence>

          {bursts.map((b) => (
            <motion.span
              key={b.id}
              initial={{ x: b.x, y: b.y, scale: 1, opacity: 1 }}
              animate={{ x: b.x + Math.cos(b.angle) * 70, y: b.y + Math.sin(b.angle) * 70, scale: 0, opacity: 0 }}
              transition={{ duration: 0.65, ease: "easeOut" }}
              className="pointer-events-none absolute top-0 left-0"
            >
              <HeartShape size={14} color={b.color} />
            </motion.span>
          ))}

          <div className="pointer-events-none absolute right-4 bottom-3 flex items-center gap-1.5 text-[#C98AA0]">
            <Target size={16} />
            <span className="text-xs font-bold tracking-wide uppercase">Ziel: alle. Für immer.</span>
          </div>
        </motion.div>

        <p className="mt-6 flex items-center justify-center gap-2 text-center font-semibold text-[#8A6270]">
          <Sparkles size={18} className="text-[#F5A623]" />
          Fun Fact: Jedes gefangene Herz ist echt. Quelle: vertrau mir.
        </p>
      </div>
    </section>
  );
}
